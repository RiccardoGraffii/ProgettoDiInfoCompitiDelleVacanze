using System.Collections.Generic;
using System.Linq;

public class GestoreDati
{
    public List<Alimentare> Alimentari{
        get;
        private set;
    }
    public List<string> CategorieAlimenti{
        get;
        private set;
    }

    public GestoreDati()
    {
        Alimentari = new List<Alimentare>();
        CategorieAlimenti = new List<string> { 
            "Ortofrutta", "Gastronomia", "Latticini", "Carne", 
            "Pesce", "Pane", "Bevande", "Dolci", "Surgele", 
            "Pasta e Riso", "Conserve", "Igiene Casa", "Igiene Persona" 
        };
    }

    public void AggiungiAlimentare(Alimentare alimentare)
    {
        Alimentari.Add(alimentare);
        OrdinaAlimentariPerNome();
    }

    public List<Alimentare> CercaAlimentari(string ricerca)
    {
        return Alimentari.Where(a => 
            a.Nome.ToLower().Contains(ricerca.ToLower()) || 
            a.Citta.ToLower().Contains(ricerca.ToLower()) ||
            a.Provincia.ToLower().Contains(ricerca.ToLower())).ToList();
    }

    public void OrdinaAlimentariPerNome()
    {
        Alimentari = Alimentari.OrderBy(a => a.Nome).ToList();
    }
}