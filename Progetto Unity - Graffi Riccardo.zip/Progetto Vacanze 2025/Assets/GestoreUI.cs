using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using System.Linq;

public class GestoreUI : MonoBehaviour
{
    [Header("Panels")]
    public GameObject panelLogin;
    public GameObject panelMainMenu;
    public GameObject panelSelezioneAlimentari;
    public GameObject panelAggiungiAlimentare;
    public GameObject panelGestioneAlimentare;
    public GameObject panelAggiungiAlimento;
    public GameObject panelDispensa;

    [Header("Login")]
    public TMP_InputField inputUsername;
    public TMP_InputField inputPassword;

    [Header("Aggiungi Alimentare")]
    public TMP_InputField inputNomeAlimentare;
    public TMP_InputField inputIndirizzo;
    public TMP_InputField inputCitta;
    public TMP_InputField inputProvincia;
    public TMP_InputField inputCAP;
    public Button btnApriMappa;

    [Header("Selezione Alimentari")]
    public TMP_Dropdown dropdownAlimentari;
    public TMP_InputField inputRicercaAlimentare;
    public Button btnGestisciSelezionato;

    [Header("Gestione Alimentare")]
    public TextMeshProUGUI testoNomeAlimentare;

    [Header("Aggiungi Alimento")]
    public TMP_Dropdown dropdownCategorie;
    public TMP_InputField inputNomeAlimento;
    public TMP_InputField inputQuantitaAlimento;

    [Header("Dispensa")]
    public TMP_Dropdown dropdownDispensa;
    public TMP_InputField inputRicercaAlimento;
    public TextMeshProUGUI testoRisultatiRicerca;

    private GestoreDati gestoreDati;
    private GestoreUtenti gestoreUtenti;
    private Alimentare alimentareSelezionato;
    private MappaManager mappaManager;

    void Start()
    {
        gestoreDati = new GestoreDati();
        gestoreUtenti = new GestoreUtenti();
        mappaManager = GetComponent<MappaManager>();
        
        MostraPanelLogin();
        gestoreDati.AggiungiAlimentare(new Alimentare("Supermercato Centro", "Via Roma 123", "Milano", "MI", "20121"));
        gestoreDati.AggiungiAlimentare(new Alimentare("Alimentari Napoli", "Piazza Garibaldi 45", "Napoli", "NA", "80142"));

        AggiornaDropdownCategorie();
        if (btnGestisciSelezionato != null){

            btnGestisciSelezionato.onClick.AddListener(GestisciAlimentareSelezionato);
        }

        
        if (btnApriMappa != null){
            btnApriMappa.onClick.AddListener(ApriMappaPosizione);
        }

        if (btnGestisciSelezionato != null){
            btnGestisciSelezionato.interactable = false;
        }



        if (inputRicercaAlimento != null){
            inputRicercaAlimento.onValueChanged.AddListener(delegate { CercaAlimenti(); });
        }
           
    }

    // METODI DI NAVIGAZIONE PRINCIPALI
    public void Accedi()
    {
        if (inputUsername == null || inputPassword == null){
            Debug.LogError("Campi di login non assegnati!");
            return;
        }

        string username = inputUsername.text;
        string password = inputPassword.text;

        if (gestoreUtenti.VerificaCredenziali(username, password)){

            MostraPanelMainMenu();
            Debug.Log("Accesso effettuato con successo!");
            
        }else{

            Debug.Log("Credenziali non valide.");
        }
    }

    public void MostraPanelLogin(){
        NascondiTuttiPanel();
        if (panelLogin != null){
            panelLogin.SetActive(true);
        }
    }

    public void MostraPanelMainMenu(){

        NascondiTuttiPanel();
        if (panelMainMenu != null) {
            panelMainMenu.SetActive(true);
        }
    }

    public void MostraPanelSelezioneAlimentari(){

        NascondiTuttiPanel();
        AggiornaDropdownAlimentari();
        if (panelSelezioneAlimentari != null){
           panelSelezioneAlimentari.SetActive(true); 
        } 
    }

    public void MostraPanelAggiungiAlimentare()
    {
        NascondiTuttiPanel();
        if (panelAggiungiAlimentare != null) panelAggiungiAlimentare.SetActive(true);
    }

    public void MostraPanelGestioneAlimentare()
    {
        if (alimentareSelezionato == null){
            Debug.Log("Nessun alimentare selezionato!");
            return;
        }
        
        NascondiTuttiPanel();
        if (testoNomeAlimentare != null){
            testoNomeAlimentare.text = $"Gestione: {alimentareSelezionato.Nome}";
        }
        if (panelGestioneAlimentare != null){
            panelGestioneAlimentare.SetActive(true);
         }
    }

    public void MostraPanelAggiungiAlimento()
    {
        if (alimentareSelezionato == null) 
        {
            Debug.Log("Nessun alimentare selezionato!");
            return;
        }
        
        NascondiTuttiPanel();
        if (panelAggiungiAlimento != null)
        {
            panelAggiungiAlimento.SetActive(true);
        }
    }

    public void MostraPanelDispensa()
    {
        if (alimentareSelezionato == null) 
        {
            Debug.Log("Nessun alimentare selezionato!");
            return;
        }
        
        NascondiTuttiPanel();
        AggiornaDropdownDispensa();
        if (panelDispensa != null)
        {
            panelDispensa.SetActive(true);
        }
    }

    private void NascondiTuttiPanel()
    {
        if (panelLogin != null){ panelLogin.SetActive(false);}
        if (panelMainMenu != null){ panelMainMenu.SetActive(false);}
        if (panelSelezioneAlimentari != null) { panelSelezioneAlimentari.SetActive(false); }
        if (panelAggiungiAlimentare != null) { panelAggiungiAlimentare.SetActive(false); }
        if (panelGestioneAlimentare != null) { panelGestioneAlimentare.SetActive(false); }
        if (panelAggiungiAlimento != null) { panelAggiungiAlimento.SetActive(false); }
        if (panelDispensa != null) { panelDispensa.SetActive(false); }
    }

    // GESTIONE ALIMENTARI
    public void AggiungiNuovoAlimentare()
    {
        if (inputNomeAlimentare == null || inputIndirizzo == null)
        {
            Debug.LogError("Input fields non assegnati!");
            return;
        }

        string nome = inputNomeAlimentare.text;
        string indirizzo = inputIndirizzo.text;
        string citta = inputCitta != null ? inputCitta.text : "";
        string provincia = inputProvincia != null ? inputProvincia.text : "";
        string cap = inputCAP != null ? inputCAP.text : "";

        if (!string.IsNullOrEmpty(nome) && !string.IsNullOrEmpty(indirizzo))
        {
            Alimentare nuovoAlimentare = new Alimentare(nome, indirizzo, citta, provincia, cap);
            gestoreDati.AggiungiAlimentare(nuovoAlimentare);


            inputNomeAlimentare.text = "";
            inputIndirizzo.text = "";
            if (inputCitta != null) { inputCitta.text = ""; }
            if (inputProvincia != null) { inputProvincia.text = ""; }
            if (inputCAP != null) { inputCAP.text = ""; }

            Debug.Log("Alimentare aggiunto: " + nome);
            
         
            MostraPanelMainMenu();
        }
    }

    public void GestisciAlimentareSelezionato()
    {
        if (dropdownAlimentari == null || gestoreDati == null || gestoreDati.Alimentari == null)
        {
            Debug.LogError("DropdownAlimentari o gestoreDati non è assegnato!");
            return;
        }

        if (dropdownAlimentari.options.Count == 0) 
        {
            Debug.Log("Nessun alimentare disponibile!");
            return;
        }
        
        int indiceSelezionato = dropdownAlimentari.value;
        if (indiceSelezionato < 0 || indiceSelezionato >= gestoreDati.Alimentari.Count)
        {
            Debug.LogError("Indice selezionato non valido!");
            return;
        }
        
        alimentareSelezionato = gestoreDati.Alimentari[indiceSelezionato];
        MostraPanelGestioneAlimentare();
    }

    public void CercaAlimentari()
    {
        if (inputRicercaAlimentare == null)
        {
            Debug.LogError("InputRicercaAlimentare non è assegnato!");
            return;
        }

        string testoRicerca = inputRicercaAlimentare.text.ToLower();
        AggiornaDropdownAlimentari(testoRicerca);
    }

   
    private void AggiornaDropdownAlimentari(string filtro = "")
    {
        if (dropdownAlimentari == null)
        {
            Debug.LogError("DropdownAlimentari non è assegnato!");
            return;
        }

        dropdownAlimentari.ClearOptions();

        if (gestoreDati == null || gestoreDati.Alimentari == null)
        {
            Debug.LogError("gestoreDati è null!");
            return;
        }

        List<Alimentare> alimentariDaMostrare = string.IsNullOrEmpty(filtro) 
            ? gestoreDati.Alimentari 
            : gestoreDati.CercaAlimentari(filtro);

        
        List<string> opzioni = new List<string>();
        foreach (var alimentare in alimentariDaMostrare)
        {
            opzioni.Add($"{alimentare.Nome} - {alimentare.Citta}");
        }

        dropdownAlimentari.AddOptions(opzioni);

      
        if (btnGestisciSelezionato != null)
        {
            btnGestisciSelezionato.interactable = (dropdownAlimentari.options.Count > 0);
        }
    }

    // GESTIONE ALIMENTI
    public void AggiungiAlimento()
    {
        if (alimentareSelezionato == null) 
        {
            Debug.Log("Nessun alimentare selezionato!");
            return;
        }

        if (inputNomeAlimento == null || inputQuantitaAlimento == null || dropdownCategorie == null)
        {
            Debug.LogError("Input fields o dropdownCategorie non assegnati!");
            return;
        }

        string nome = inputNomeAlimento.text;
        string categoria = dropdownCategorie.options[dropdownCategorie.value].text;
        
        if (string.IsNullOrEmpty(nome) || string.IsNullOrEmpty(inputQuantitaAlimento.text))
        {
            Debug.Log("Inserisci nome e quantità dell'alimento!");
            return;
        }
        
        int quantita;
        if (!int.TryParse(inputQuantitaAlimento.text, out quantita))
        {
            Debug.Log("La quantità deve essere un numero intero!");
            return;
        }
        
        alimentareSelezionato.AggiungiAlimento(nome, categoria, quantita);
        
     
        inputNomeAlimento.text = "";
        inputQuantitaAlimento.text = "";
        
        Debug.Log($"Aggiunto {quantita} unità di {nome} a {alimentareSelezionato.Nome}");
        

        MostraPanelGestioneAlimentare();
    }

    // DISPENSA 
    public void CercaAlimenti()
    {
        if (inputRicercaAlimento == null)
        {
            Debug.LogError("InputRicercaAlimento non è assegnato!");
            return;
        }

        string testoRicerca = inputRicercaAlimento.text;
        AggiornaDropdownDispensa(testoRicerca);
    }

    private void AggiornaDropdownDispensa(string filtro = "")
    {
        if (dropdownDispensa == null)
        {
            Debug.LogError("DropdownDispensa non è assegnato!");
            return;
        }

        dropdownDispensa.ClearOptions();

        if (alimentareSelezionato == null) 
        {
            Debug.Log("Nessun alimentare selezionato!");
            return;
        }

   
        List<string> opzioni = new List<string>();
        int risultati = 0;
        
        foreach (var categoria in alimentareSelezionato.AlimentiPerCategoria.Keys)
        {
            foreach (var alimento in alimentareSelezionato.AlimentiPerCategoria[categoria])
            {
  
                if (!string.IsNullOrEmpty(filtro) && 
                    !alimento.Key.ToLower().Contains(filtro.ToLower()) && 
                    !categoria.ToLower().Contains(filtro.ToLower()))
                {
                    continue;
                }

                opzioni.Add($"{alimento.Key} ({categoria}): {alimento.Value} unità");
                risultati++;
            }
        }

        dropdownDispensa.AddOptions(opzioni);
        

        if (testoRisultatiRicerca != null)
        {
            testoRisultatiRicerca.text = $"Trovati {risultati} risultati";
        }
    }

    private void AggiornaDropdownCategorie()
    {
        if (dropdownCategorie == null)
        {
            Debug.LogError("DropdownCategorie non è assegnato! Controlla l'Inspector.");
            return;
        }
        
        if (gestoreDati == null || gestoreDati.CategorieAlimenti == null)
        {
            Debug.LogError("gestoreDati o CategorieAlimenti è null!");
            return;
        }

        dropdownCategorie.ClearOptions();
        dropdownCategorie.AddOptions(gestoreDati.CategorieAlimenti);
    }

    // INTEGRAZIONE GOOGLE MAPS - FALLITO
    public void ApriMappaPosizione()
    {
        if (inputIndirizzo == null || inputCitta == null)
        {
            Debug.LogError("Input fields per la mappa non assegnati!");
            return;
        }

        if (string.IsNullOrEmpty(inputIndirizzo.text) || string.IsNullOrEmpty(inputCitta.text))
        {
            Debug.Log("Inserisci almeno indirizzo e città per aprire la mappa!");
            return;
        }
        
        string indirizzoCompleto = $"{inputIndirizzo.text}, {inputCitta.text} {inputProvincia?.text} {inputCAP?.text}";
        if (mappaManager != null)
            mappaManager.ApriMappa(indirizzoCompleto);
        else
            Debug.LogError("MappaManager non è assegnato!");
    }

    // METODI PER TORNARE INDIETRO
    public void TornaAlMenuPrincipale()
    {
        MostraPanelMainMenu();
    }
    
    public void TornaASelezioneAlimentari()
    {
        MostraPanelSelezioneAlimentari();
    }
    
    public void TornaAGestioneAlimentare()
    {
        MostraPanelGestioneAlimentare();
    }

    // METODO DI DEBUG PER VERIFICARE I RIFERIMENTI
    public void DebugRiferimenti()
    {
        Debug.Log("=== DEBUG RIFERIMENTI ===");
        Debug.Log($"Dropdown Alimentari: {dropdownAlimentari != null}");
        Debug.Log($"Dropdown Dispensa: {dropdownDispensa != null}");
        Debug.Log($"Input Ricerca Alimentari: {inputRicercaAlimentare != null}");
        Debug.Log($"Input Ricerca Alimenti: {inputRicercaAlimento != null}");
        Debug.Log($"Btn Gestisci: {btnGestisciSelezionato != null}");
        Debug.Log("=========================");
    }
}