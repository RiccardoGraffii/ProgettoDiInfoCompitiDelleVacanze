using System.Collections.Generic;

public class GestoreUtenti
{
    private Dictionary<string, string> utentiRegistrati;

    public GestoreUtenti()
    {
        utentiRegistrati = new Dictionary<string, string>();
        utentiRegistrati.Add("Riccardo", "1234");
        utentiRegistrati.Add("User", "0000");
         utentiRegistrati.Add("user", "0000");
    }

    public bool VerificaCredenziali(string username, string password)
    {
        if (utentiRegistrati.ContainsKey(username) && utentiRegistrati[username] == password)
        {
            return true;
        }
        return false;
    }
}