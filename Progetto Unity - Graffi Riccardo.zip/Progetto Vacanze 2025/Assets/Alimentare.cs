using System.Collections.Generic;

public class Alimentare
{
    public string Nome{
        get;
        set;
    }
    public string Indirizzo{
        get;
        set;
    }
    public string Citta{
        get;
        set;
    }
    public string Provincia{
        get;
        set; 
    }
    public string CAP{
        get;
        set; 
    }
    public Dictionary<string, Dictionary<string, int>> AlimentiPerCategoria{
        get;
        private set;
    }

    public Alimentare(string nome, string indirizzo, string citta, string provincia, string cap)
    {
        Nome = nome;
        Indirizzo = indirizzo;
        Citta = citta;
        Provincia = provincia;
        CAP = cap;
        AlimentiPerCategoria = new Dictionary<string, Dictionary<string, int>>();
    }

    public void AggiungiAlimento(string nomeAlimento, string categoria, int quantita)
    {
        if (!AlimentiPerCategoria.ContainsKey(categoria))
        {
            AlimentiPerCategoria[categoria] = new Dictionary<string, int>();
        }

        if (AlimentiPerCategoria[categoria].ContainsKey(nomeAlimento))
        {
            AlimentiPerCategoria[categoria][nomeAlimento] += quantita;
        }
        else
        {
            AlimentiPerCategoria[categoria][nomeAlimento] = quantita;
        }
    }

    public int OttieniQuantitaAlimento(string nomeAlimento, string categoria)
    {
        if (AlimentiPerCategoria.ContainsKey(categoria) && AlimentiPerCategoria[categoria].ContainsKey(nomeAlimento))
        {
            return AlimentiPerCategoria[categoria][nomeAlimento];
        }
        return 0;
    }
}