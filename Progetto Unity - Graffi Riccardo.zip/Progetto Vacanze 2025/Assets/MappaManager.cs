using UnityEngine;

public class MappaManager : MonoBehaviour
{
    public void ApriMappa(string indirizzoCompleto)
    {
        string url = $"https://www.google.com/maps/search/?api=1&query={WWW.EscapeURL(indirizzoCompleto)}";
        Application.OpenURL(url);
        Debug.Log("Apertura mappa per: " + indirizzoCompleto);
    }
}